Maam Ganda wala pa po yung sa individual ko di pa po tapos ihahabol ko nalang po thankyou po :)

-Ricafort
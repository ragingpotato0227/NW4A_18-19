﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1.Default_Con
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Charlie";
            lastname = "Ricafort";
        }
    }
}
